/*
INTEGRANTES DO GRUPO:
                    Felipe da Costa Coqueiro,   NºUSP: 11781361
                    Fernando Alee Suaiden,      NºUSP: 12680836
*/

#ifndef FUNCOESf_H
    #define FUNCOESf_H

    void binarioNaTela(char *nomeArquivoBinario);
    void scan_quote_string(char *str);
    
#endif